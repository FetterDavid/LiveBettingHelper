namespace LiveBettingHelper.Views;

public partial class Test : ContentPage
{
	public Test()
	{
		InitializeComponent();
	}
}