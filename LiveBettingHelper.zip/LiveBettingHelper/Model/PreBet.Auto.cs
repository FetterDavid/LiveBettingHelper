﻿using SQLite;

namespace LiveBettingHelper.Model
{
    public partial class PreBet : BetBase
    {

    }
}
