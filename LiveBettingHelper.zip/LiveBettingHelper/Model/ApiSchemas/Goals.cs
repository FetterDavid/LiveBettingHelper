﻿namespace LiveBettingHelper.Model.ApiSchemas
{
    public class Goals
    {
        public int? home { get; set; }
        public int? away { get; set; }
    }

}
