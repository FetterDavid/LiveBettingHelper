﻿namespace LiveBettingHelper.Model.ApiSchemas
{
    public class Teams
    {
        public Home home { get; set; }
        public Away away { get; set; }
    }

}
