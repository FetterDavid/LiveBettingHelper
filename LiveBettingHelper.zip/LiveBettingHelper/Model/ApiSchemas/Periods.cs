﻿namespace LiveBettingHelper.Model.ApiSchemas
{
    public class Periods
    {
        public int? first { get; set; }
        public int? second { get; set; }
    }

}
