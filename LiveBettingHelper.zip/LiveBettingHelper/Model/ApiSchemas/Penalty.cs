﻿namespace LiveBettingHelper.Model.ApiSchemas
{
    public class Penalty
    {
        public object home { get; set; }
        public object away { get; set; }
    }

}
