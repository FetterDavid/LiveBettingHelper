﻿namespace LiveBettingHelper.Model.ApiSchemas
{
    public class Time
    {
        public int elapsed { get; set; }
        public int? extra { get; set; }
    }

}
