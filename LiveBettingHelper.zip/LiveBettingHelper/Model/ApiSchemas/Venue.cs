﻿namespace LiveBettingHelper.Model.ApiSchemas
{
    public class Venue
    {
        public int? id { get; set; }
        public string name { get; set; }
        public string city { get; set; }
    }

}
