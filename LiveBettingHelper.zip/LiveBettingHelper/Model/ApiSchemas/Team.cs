﻿namespace LiveBettingHelper.Model.ApiSchemas
{
    public class Team
    {
        public int id { get; set; }
        public string name { get; set; }
        public string logo { get; set; }
    }

}
