﻿namespace LiveBettingHelper.Model.ApiSchemas
{
    public class Status
    {
        public string _long { get; set; }
        public string _short { get; set; }
        public int? elapsed { get; set; }
    }

}
