﻿namespace LiveBettingHelper.Model.ApiSchemas
{
    public class Halftime
    {
        public int? home { get; set; }
        public int? away { get; set; }
    }

}
