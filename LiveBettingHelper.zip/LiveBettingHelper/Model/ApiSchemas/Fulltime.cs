﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LiveBettingHelper.Model.ApiSchemas
{

    public class Fulltime
    {
        public int? home { get; set; }
        public int? away { get; set; }
    }

}
