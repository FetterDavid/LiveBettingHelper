﻿namespace LiveBettingHelper.Model.ApiSchemas
{
    public class Assist
    {
        public int? id { get; set; }
        public string name { get; set; }
    }

}
