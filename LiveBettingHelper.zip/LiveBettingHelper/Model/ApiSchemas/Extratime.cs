﻿namespace LiveBettingHelper.Model.ApiSchemas
{
    public class Extratime
    {
        public object home { get; set; }
        public object away { get; set; }
    }

}
