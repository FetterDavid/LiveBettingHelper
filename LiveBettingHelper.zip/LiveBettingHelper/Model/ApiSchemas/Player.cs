﻿namespace LiveBettingHelper.Model.ApiSchemas
{
    public class Player
    {
        public int? id { get; set; }
        public string name { get; set; }
    }

}
