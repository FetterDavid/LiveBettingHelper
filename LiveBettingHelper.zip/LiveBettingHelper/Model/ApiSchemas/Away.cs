﻿namespace LiveBettingHelper.Model.ApiSchemas
{
    public class Away
    {
        public int id { get; set; }
        public string name { get; set; }
        public string logo { get; set; }
        public bool? winner { get; set; }
    }

}
